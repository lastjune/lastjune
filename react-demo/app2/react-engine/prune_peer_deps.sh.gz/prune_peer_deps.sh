#!/bin/sh

echo "Executing: rm -rf node_modules/react"
rm -rf node_modules/react

echo "Executing: rm -rf node_modules/express"
rm -rf node_modules/express

echo "Executing: rm -rf node_modules/react-router"
rm -rf node_modules/react-router
