#### a complex express app to demonstrate the usage of react-engine

##### Uses react views and react-router views

###### to run
```shell
cd `into_this_dir`
npm install
npm start
open http://localhost:3000
```
