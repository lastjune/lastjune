#### a react app bootstrapped using webpack on the client side

###### to run
```shell
cd `into_this_dir`
npm install
npm start
open http://localhost:3000
```
