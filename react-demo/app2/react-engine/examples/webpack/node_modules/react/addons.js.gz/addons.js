module.exports = require('./lib/ReactWithAddons');
