require.requireActual('./polyfill/Object.es6.js');
