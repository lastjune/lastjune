class X {
  constructor() {
    throw new Error('wtf');
  }
}

module.exports = new X();
