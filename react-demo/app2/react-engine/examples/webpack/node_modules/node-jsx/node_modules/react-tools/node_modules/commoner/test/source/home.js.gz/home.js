require("assert");
require("./assert");
require("./tests/../assert");

exports.name = "home";
