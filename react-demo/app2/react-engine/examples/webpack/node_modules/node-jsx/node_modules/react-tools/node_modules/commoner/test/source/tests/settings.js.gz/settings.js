exports.name = "tests/settings";
