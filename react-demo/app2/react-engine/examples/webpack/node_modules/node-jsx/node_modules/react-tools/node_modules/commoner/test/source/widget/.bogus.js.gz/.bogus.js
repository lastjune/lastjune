/**
 * This is a temporary file such as VIM is wont to create.
 * @providesModule WidgetShare
 */
