The files in this directory are modified from their original implementation. At some point the files here were included in the React package shipped to npm and used by other projects.

We removed all uses of these files inside React itself but would like to provide a sane deprecation notice for other consumers. We made no promises about the files here; they were always "use at your own risk".
