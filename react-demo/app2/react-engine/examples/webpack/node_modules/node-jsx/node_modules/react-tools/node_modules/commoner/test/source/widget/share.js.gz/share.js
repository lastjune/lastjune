/**
 * @providesModule WidgetShare
 */

// @providesModule ignore this
exports.name = "widget/share";
