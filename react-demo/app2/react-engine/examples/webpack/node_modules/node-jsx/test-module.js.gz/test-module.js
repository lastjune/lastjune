/** @jsx React.DOM */

function jonx() {
  return 'jonx';
}

module.exports = <jonx />;