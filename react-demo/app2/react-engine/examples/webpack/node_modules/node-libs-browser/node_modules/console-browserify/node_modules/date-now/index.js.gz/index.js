module.exports = now

function now() {
    return new Date().getTime()
}
