# History

## v1.1.4 February 3, 2015
- Added
	- `domain.enter()`
	- `domain.exit()`
	- `domain.bind()`
	- `domain.intercept()`

## v1.1.3 October 10, 2014
- Added
	- `domain.add()`
 	- `domain.remove()`

## v1.1.2 June 8, 2014
- Added `domain.createDomain()` alias
	- Thanks to [James Halliday](https://github.com/substack) for [pull request #1](https://github.com/bevry/domain-browser/pull/1)

## v1.1.1 December 27, 2013
- Fixed `domain.create()` not returning anything

## v1.1.0 November 1, 2013
- Dropped component.io and bower support, just use ender or browserify

## v1.0.1 September 18, 2013
- Now called `domain-browser` everywhere

## v1.0.0 September 18, 2013
- Initial release
