require("../widget/share");
require("./share");
require("WidgetShare");

exports.name = "widget/gallery";
