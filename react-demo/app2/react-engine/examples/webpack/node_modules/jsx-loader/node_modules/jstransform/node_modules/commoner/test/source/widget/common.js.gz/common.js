exports.name = "widget/common";
