// CommentForm.jsx

'use strict';

var React = require('react');
var CommentForm;

module.exports = CommentForm = React.createClass({
    render: function() {
        return (
            <div className="commentForm">
            </div>
            );
    }
})
